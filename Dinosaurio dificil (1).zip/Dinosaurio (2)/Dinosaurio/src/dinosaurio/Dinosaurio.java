package dinosaurio;

import java.io.File;
import java.io.InputStream;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.shape.Circle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.input.KeyCombination;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import dinosaurio.Sonidos;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.MotionBlur;
import javafx.scene.text.TextAlignment;

import java.util.Optional;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.DialogPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;

public class Dinosaurio extends Application {

    //Todas las variables definidas
    private static final int SCENE_WIDTH = 1200;
    private static final int SCENE_HEIGHT = 800;
    private static final int PLAYER_RADIUS = 40;
    private static final int ENEMY_RADIUS = 30;
    private static final int BULLET_RADIUS = 6;
    private static final int METEOR_RADIUS = 20;
    private static final double OBSTACLE_SPEED = 1.5;
    private static final int MAX_HEALTH = 100;

    private boolean levelIncreased = false;
    private double enemySpawnRate = 0.01;
    private int lives = 3;

    private Pane root;
    private int currentPlayer = 1;
    private int player1Score = 0;
    private int player2Score = 0;
    private Player player;
    private List<Enemy> enemies;
    private List<Bullet> bullets;
    private List<Circle> obstacles;
    private ImageView defense;
    private int health = MAX_HEALTH;
    private int score = 0;
    private Text scoreText;
    private Text livesText;

    private int level = 1;
    private boolean isPaused = false;
    private Pane menuPane;
    private int menuOption = 0;
    private Rectangle healthBar;
    private static final double HEALTH_BAR_WIDTH = 200;
    private boolean isGameOver = false;

    public static void main(String[] args) {
        launch(args);

    }
    //Metodo start en el que inicamos imagenes metodos de otras clases y la funcionalidad de algunas teclas

    @Override
    public void start(Stage primaryStage) {
        root = new Pane();
        Scene scene = new Scene(root, SCENE_WIDTH, SCENE_HEIGHT);

        MenuPrincipal.mostrarMenuPrincipal();

        Image icon = new Image("file:images/videojuego.png");
        primaryStage.getIcons().add(icon);

        Sonidos.reproducirFondo();

        primaryStage.setResizable(false);

        Image backgroundImage = new Image("file:images/fondoespacio.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setFitWidth(SCENE_WIDTH);
        backgroundView.setFitHeight(SCENE_HEIGHT);
        root.getChildren().add(backgroundView);

        livesText = new Text("Vidas: " + lives);
        livesText.setFill(Color.WHITE);
        livesText.setFont(Font.font("Arial", 20));
        livesText.setTranslateX(10);
        livesText.setTranslateY(80);
        root.getChildren().add(livesText);

        Text pauseMessage = new Text("Presiona ESC para pausar");
        pauseMessage.setFont(Font.font("Arial", 20));
        pauseMessage.setFill(Color.WHITE);
        pauseMessage.setTranslateX(SCENE_WIDTH - pauseMessage.getBoundsInLocal().getWidth() - 10);
        pauseMessage.setTranslateY(20);
        root.getChildren().add(pauseMessage);

        healthBar = new Rectangle(HEALTH_BAR_WIDTH, 20);
        healthBar.setFill(Color.GREEN);
        healthBar.setTranslateX((SCENE_WIDTH - HEALTH_BAR_WIDTH) / 2);
        healthBar.setTranslateY(10);  // Distancia desde la parte superior
        root.getChildren().add(healthBar);

        player = new Player("file:images/nave.png", SCENE_WIDTH / 2, SCENE_HEIGHT - 50);
        root.getChildren().add(player.getCircle());

        enemies = new ArrayList<>();
        bullets = new ArrayList<>();
        obstacles = new ArrayList<>();

        Image defenseImage = new Image("file:images/tierra2.png");
        defense = new ImageView(defenseImage);
        defense.setFitWidth(SCENE_WIDTH);  // Configura el ancho para que ocupe todo el panel horizontalmente
        defense.setFitHeight(20);
        defense.setY(SCENE_HEIGHT - 20 - 10);
        root.getChildren().add(defense);

        scoreText = new Text("Score: 0 | Level: 1");
        scoreText.setFill(Color.PINK);
        scoreText.setFont(Font.font("Arial", 30));
        scoreText.setTranslateX(10);
        scoreText.setTranslateY(50);
        root.getChildren().add(scoreText);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Defender Game");
        primaryStage.show();

        scene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                togglePauseMenu();
            } else if (!isPaused) {
                player.handleKeyPress(event.getCode());
                if (event.getCode() == KeyCode.SPACE) {
                    player.shoot();
                }
            }
        });

        scene.setOnKeyReleased(event -> {
            if (!isPaused) {
                player.handleKeyRelease(event.getCode());
            }
        });

        primaryStage.setScene(scene);
        primaryStage.setTitle("Defender Game");
        primaryStage.show();

        createGameLoop();
        createPauseMenu();
    }

    private void createGameLoop() {
        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (!isPaused) {
                    updateGame();
                }
            }
        };
        timer.start();
    }
    
    //Todo lo que esta relaciona con actualizar el juego se encuentra aqui

    private void updateGame() {
        player.move();
        moveBullets();
        moveEnemies();
        moveObstacles();

        checkCollisions();

        if (Math.random() < enemySpawnRate) {
            addEnemy();
        }

        if (score >= 30 && score % 30 == 0 && !levelIncreased) {
            level++;
            levelIncreased = true;
            increaseDifficulty();
        } else if (score % 30 != 0) {
            levelIncreased = false;
        }

        if (score >= 150) {
            pauseGame();
            showVictoryMessage();
            Sonidos.reproducirGanar();  // Reproduce el sonido de victoria
            isGameOver = true;

        } else if (health <= 0) {
            pauseGame();
            showDefeatMessage();
            Sonidos.reproducirPerder();  // Reproduce el sonido de derrota
            isGameOver = true;

        }

        updateHealthBar();
    }

    private void pauseGame() {
        isPaused = true;
    }

    private void resumeGame() {
        isPaused = false;
    }

   // Todo lo que conlleva ganar

    private void showVictoryMessage() {
        Sonidos.reproducirPerder();

        PauseTransition delay = new PauseTransition(Duration.seconds(4));
        Text victoryText = createCenteredText("¡Enhorabuena!\nSalvaste la Tierra");
        root.getChildren().add(victoryText);

        delay.setOnFinished(event -> {
            root.getChildren().remove(victoryText);
            mostrarOpcionesRejugarSalir();
        });
        delay.play();
    }

    private void loseLife() {
        lives--;
        livesText.setText("Vidas: " + lives);

        // Otras acciones al perder una vida, si es necesario
        if (lives <= 0) {
            gameOver();
            pauseGame();
            Sonidos.reproducirPerder();

        }
    }
    //Cuando se pierde debido a la destruccion de la nave
    private void gameOver() {
        PauseTransition delay = new PauseTransition(Duration.seconds(3));
        Text gameOverText = createCenteredText("¡Has perdido!\nLa Tierra se destruyó");
        root.getChildren().add(gameOverText);

        delay.setOnFinished(event -> {
            root.getChildren().remove(gameOverText);
            mostrarOpcionesRejugarSalir();
        });
        delay.play();
    }
    //Cuando se pierde debido a la destruccion del planeta 
    private void showDefeatMessage() {
        Sonidos.reproducirGanar();

        PauseTransition delay = new PauseTransition(Duration.seconds(4));
        Text defeatText = createCenteredText("¡Fallaste!\nLa Tierra se destruyó");
        root.getChildren().add(defeatText);

        delay.setOnFinished(event -> {
            root.getChildren().remove(defeatText);
            mostrarOpcionesRejugarSalir();
        });
        delay.play();
    }
    
    // Cuando acaba la partida que salgas dos opciones rejugar salir 

    private void mostrarOpcionesRejugarSalir() {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Opciones");
            alert.setHeaderText("¿Qué deseas hacer?");

            ButtonType buttonTypeRejugar = new ButtonType("Rejugar");
            ButtonType buttonTypeSalir = new ButtonType("Salir", ButtonData.CANCEL_CLOSE);

            alert.getButtonTypes().setAll(buttonTypeRejugar, buttonTypeSalir);

            Optional<ButtonType> result = alert.showAndWait();

            result.ifPresent(response -> {
                if (response == buttonTypeRejugar) {
                    // Lógica para reiniciar la aplicación
                    System.out.println("Rejugar");
                    reiniciarApp();
                } else if (response == buttonTypeSalir) {
                    // Lógica para salir del juego
                    System.out.println("Salir del Juego");
                    Platform.exit();
                }
            });
        });
    }

    private void reiniciarApp() {
        Platform.runLater(() -> {
            // Obtener la ventana actual
            Stage stage = (Stage) root.getScene().getWindow();

            try {
                // Cerrar la ventana actual
                stage.close();

                // Crear y mostrar una nueva instancia de la aplicación
                new Dinosaurio().start(new Stage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    //Metodo usado en los mensajes de victoria o derrota
    private Text createCenteredText(String message) {
        Text text = new Text(message);
        text.setFont(Font.font("Arial", 30));
        text.setFill(Color.WHITE);
        text.setTextAlignment(TextAlignment.CENTER);
        text.setWrappingWidth(SCENE_WIDTH);
        text.setTranslateY(SCENE_HEIGHT / 2 - text.getBoundsInLocal().getHeight() / 2);
        return text;
    }

    private void endGame() {

        if (health > 0) {
            // Si la salud es mayor que cero, el jugador ha ganado
            System.out.println("¡Victoria! Score: " + score);
        } else {
            // Si la salud es cero o menos, el jugador ha perdido
            System.out.println("¡Derrota! Score: " + score);
        }
        isGameOver = true;
    }
    //Actualizar la barra de vida de la tierra
    private void updateHealthBar() {
        double ratio = (double) health / MAX_HEALTH;
        healthBar.setWidth(HEALTH_BAR_WIDTH * ratio);
        Color barColor = Color.rgb((int) (255 * (1 - ratio)), (int) (255 * ratio), 0);
        healthBar.setFill(barColor);

        if (health <= 0) {
            endGame();

        }
    }

    // El daño que le hacen los obstaculos a la tierra
    private void reduceHealth() {
        // Reducir la salud más rápido 
        health -= 25;
        updateHealthBar();
    }
    
    //El incremento de enemigos dependiendo del nivel
    private void increaseDifficulty() {
        for (Enemy enemy : enemies) {
            enemy.increaseSpeed();
        }

        if (level == 2) {
            enemySpawnRate = 0.03;
        } else if (level == 3) {
            enemySpawnRate = 0.03;
        } else if (level > 3) {
            enemySpawnRate = 0.04;
        }
    }
    //Mover las balas
    private void moveBullets() {
        Iterator<Bullet> bulletIterator = bullets.iterator();
        while (bulletIterator.hasNext()) {
            Bullet bullet = bulletIterator.next();
            bullet.move();

            if (!isInBounds(bullet.getCircle())) {
                bulletIterator.remove();
                root.getChildren().remove(bullet.getCircle());
            }
        }
    }

    private void moveEnemies() {
        Iterator<Enemy> enemyIterator = enemies.iterator();
        while (enemyIterator.hasNext()) {
            Enemy enemy = enemyIterator.next();
            enemy.move();

            if (!isInBounds(enemy.getCircle())) {
                enemyIterator.remove();
                root.getChildren().remove(enemy.getCircle());
            }
        }
    }

    private void moveObstacles() {
        Iterator<Circle> obstacleIterator = obstacles.iterator();
        while (obstacleIterator.hasNext()) {
            Circle obstacle = obstacleIterator.next();
            obstacle.setCenterY(obstacle.getCenterY() + OBSTACLE_SPEED);

            if (!isInBounds(obstacle)) {
                obstacleIterator.remove();
                root.getChildren().remove(obstacle);
            }
        }
    }
    // Metodo para que todas las colisiones funcionen
    private void checkCollisions() {
        checkBulletEnemyCollisions();
        checkPlayerEnemyCollisions();
        checkEnemyDefenseCollisions();
        checkObstacleCollisions();
    }
    
//Colisiones de las balas con los enemigos
    private void checkBulletEnemyCollisions() {
        List<Bullet> bulletsToRemove = new ArrayList<>();
        List<Enemy> enemiesToRemove = new ArrayList<>();

        for (Bullet bullet : bullets) {
            for (Enemy enemy : enemies) {
                if (bullet.intersects(enemy.getCircle())) {
                    bulletsToRemove.add(bullet);
                    enemiesToRemove.add(enemy);
                    increaseScore();
                }
            }
        }

        root.getChildren().removeAll(bulletsToRemove.stream().map(Bullet::getCircle).collect(Collectors.toList()));
        root.getChildren().removeAll(enemiesToRemove.stream().map(Enemy::getCircle).collect(Collectors.toList()));

        bullets.removeAll(bulletsToRemove);
        enemies.removeAll(enemiesToRemove);
    }
//Las colisiones del jugador con obstaculos
    private void checkPlayerEnemyCollisions() {
        Iterator<Enemy> enemyIterator = enemies.iterator();
        while (enemyIterator.hasNext()) {
            Enemy enemy = enemyIterator.next();

            if (player.intersects(enemy.getCircle())) {
                enemyIterator.remove();
                root.getChildren().remove(enemy.getCircle());

                loseLife();
            }
        }
    }
    

    private void checkEnemyDefenseCollisions() {
        Iterator<Enemy> enemyIterator = enemies.iterator();
        while (enemyIterator.hasNext()) {
            Enemy enemy = enemyIterator.next();

            if (enemy.intersects(defense.getBoundsInParent())) {
                enemyIterator.remove();
                root.getChildren().remove(enemy.getCircle());
                reduceHealth();
            }
        }
    }

    private void checkObstacleCollisions() {
        Iterator<Circle> obstacleIterator = obstacles.iterator();
        while (obstacleIterator.hasNext()) {
            Circle obstacle = obstacleIterator.next();

            if (player.intersects(obstacle)) {
                obstacleIterator.remove();
                root.getChildren().remove(obstacle);
                //  cuando hay colisión con el obstáculo
                reduceHealth();
                loseLife();

            }
        }
    }
    
//Para que se sumen enemigos y tengan una velociad random
    private void addEnemy() {
        double initialVelocityY = (((Math.random()*2)+1)-0.5);
        Enemy enemy = new Enemy(Math.random() * SCENE_WIDTH, 0, initialVelocityY);
        enemies.add(enemy);
        root.getChildren().add(enemy.getCircle());

        // Agregar un rastro al enemigo
        Trail trail = new Trail(enemy.getCircle().getCenterX(), enemy.getCircle().getCenterY());
        root.getChildren().add(trail);

        // Animación para eliminar el rastro después de cierto tiempo
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), new KeyValue(trail.opacityProperty(), 0)));
        timeline.setOnFinished(event -> root.getChildren().remove(trail));
        timeline.play();
    }
    
//Crear efectos para los obstaculos
    private class Trail extends Circle {

        private static final int TRAIL_RADIUS = 5;
        private static final Color TRAIL_COLOR = Color.rgb(255, 165, 0, 0.3); // Naranja transparente

        public Trail(double x, double y) {
            super(x, y, TRAIL_RADIUS, TRAIL_COLOR);
            setEffect(createTrailEffect());
        }

        private MotionBlur createTrailEffect() {
            MotionBlur motionBlur = new MotionBlur();
            motionBlur.setRadius(5);
            motionBlur.setAngle(45);
            return motionBlur;
        }

        public void updatePosition(double x, double y) {
            setCenterX(x);
            setCenterY(y);
        }
    }
    //Aumentar la puntuacion

    private void increaseScore() {
        if (currentPlayer == 1) {
            player1Score++;
        } else {
            player2Score++;
        }
        score++;
        scoreText.setText("Score: " + score + " | Level: " + level);
    }

    private void updateDefenseColor() {
        double ratio = (double) health / MAX_HEALTH;
        Color newColor = Color.rgb((int) (255 * (1 - ratio)), (int) (255 * ratio), 0);
        defense.setImage(new Image("file:images/tierra2.png"));
    }

    private boolean isInBounds(Circle circle) {
        Bounds bounds = root.getBoundsInLocal();
        return circle.getBoundsInParent().intersects(bounds);
    }
    //Clase Player donde defino los movimientos y de donde salen las balas
    private class Player {

        private ImageView imageView;
        private boolean up, down, left, right;

        Player(String imageUrl, double x, double y) {
            Image image = new Image(imageUrl);
            imageView = new ImageView(image);
            imageView.setFitWidth(2 * PLAYER_RADIUS);
            imageView.setFitHeight(2 * PLAYER_RADIUS);
            imageView.setX(x - PLAYER_RADIUS);
            imageView.setY(y - PLAYER_RADIUS);
        }

        void shoot() {
            double bulletX1 = imageView.getX() + imageView.getFitWidth() / 2 - BULLET_RADIUS;

            Bullet bullet1 = new Bullet(Color.BLACK, bulletX1, imageView.getY());

            bullets.add(bullet1);

            root.getChildren().addAll(bullet1.getCircle());
        }

        void move() {
            if (up && imageView.getY() > 0) {
                imageView.setY(imageView.getY() - 8);
            }
            if (down && imageView.getY() < SCENE_HEIGHT - 2 * PLAYER_RADIUS) {
                imageView.setY(imageView.getY() + 8);
            }
            if (left && imageView.getX() > 0) {
                imageView.setX(imageView.getX() - 8);
            }
            if (right && imageView.getX() < SCENE_WIDTH - 2 * PLAYER_RADIUS) {
                imageView.setX(imageView.getX() + 8);
            }
        }

        ImageView getCircle() {
            return imageView;
        }

        boolean intersects(Circle other) {
            return imageView.getBoundsInParent().intersects(other.getBoundsInParent());
        }

        void handleKeyPress(KeyCode code) {
            switch (code) {
                case UP:
                    up = true;
                    break;
                case DOWN:
                    down = true;
                    break;
                case LEFT:
                    left = true;
                    break;
                case RIGHT:
                    right = true;
                    break;
            }
        }

        void handleKeyRelease(KeyCode code) {
            switch (code) {
                case UP:
                    up = false;
                    break;
                case DOWN:
                    down = false;
                    break;
                case LEFT:
                    left = false;
                    break;
                case RIGHT:
                    right = false;
                    break;
            }
        }
    }
    //Defino a los enemigos su velocidad a algunos aspectos visuales de estos

    private class Enemy {

        private Circle circle;
        private double velocityY = 1;
        private double speed = 1;

        Enemy(double x, double y, double initialVelocityY) {
            // Utilizamos un gradiente radial para dar un aspecto más realista al meteorito
            RadialGradient gradient = new RadialGradient(
                    0, // focusAngle
                    0.1, // focusDistance
                    x / SCENE_WIDTH, y / SCENE_HEIGHT, // centerX, centerY
                    METEOR_RADIUS, // radius
                    false, // proportional
                    CycleMethod.NO_CYCLE, // cycleMethod
                    new Stop(0.0, Color.DARKGRAY), // colores del centro
                    new Stop(1.0, Color.BLACK) // colores del borde
            );

            // Creamos el círculo con el gradiente
            circle = new Circle(METEOR_RADIUS, gradient);
            circle.setCenterX(x);
            circle.setCenterY(y);

            // Aplicar efecto de sombra para simular la apariencia de un meteorito
            DropShadow dropShadow = new DropShadow(10, Color.RED);
            circle.setEffect(dropShadow);

            velocityY = initialVelocityY;
        }

        // Resto del código de la clase Enemy...
        void move() {
            circle.setCenterY(circle.getCenterY() + velocityY * speed);
        }

        boolean intersects(Bounds bounds) {
            return circle.getBoundsInParent().intersects(bounds);
        }

        Circle getCircle() {
            return circle;
        }

        void increaseSpeed() {
            speed += 1.2;
        }
    }
    
//Defino las balas el movimiento
    private class Bullet {

        private Circle circle;
        private double velocityY = -5;

        Bullet(Color color, double x, double y) {
            circle = new Circle(BULLET_RADIUS, color);
            circle.setCenterX(x);
            circle.setCenterY(y);
        }

        void move() {
            circle.setCenterY(circle.getCenterY() + velocityY);
        }

        Circle getCircle() {
            return circle;
        }

        boolean intersects(Circle other) {
            return circle.getBoundsInParent().intersects(other.getBoundsInParent());
        }
    }
    
//creo el menu de pausa dandole a esc y obviamente pausa el juego 
    private void createPauseMenu() {
        menuPane = new Pane();
        menuPane.setPrefSize(SCENE_WIDTH, SCENE_HEIGHT);
        menuPane.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7);");

        Text resumeText = new Text("Press ESC to Resume");
        resumeText.setFont(Font.font("Arial", 30));
        resumeText.setFill(Color.WHITE);
        resumeText.setTranslateX(SCENE_WIDTH / 2 - resumeText.getBoundsInLocal().getWidth() / 2);
        resumeText.setTranslateY(SCENE_HEIGHT / 2 - resumeText.getBoundsInLocal().getHeight() / 2);

        menuPane.getChildren().add(resumeText);
        root.getChildren().add(menuPane);
        menuPane.setVisible(false);
    }

    private void togglePauseMenu() {
        isPaused = !isPaused;
        menuPane.setVisible(isPaused);
    }
}
