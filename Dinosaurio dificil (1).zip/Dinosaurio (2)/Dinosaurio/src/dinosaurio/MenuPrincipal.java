package dinosaurio;

import dinosaurio.Sonidos;
import java.util.Optional;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.StageStyle;

public class MenuPrincipal {

    public static void mostrarMenuPrincipal() {
        // Configurar la imagen de fondo
        Sonidos.reproducirMenu();
        Image backgroundImage = new Image("file:images/fondomenu.png");
        ImageView backgroundView = new ImageView(backgroundImage);
        Sonidos.reproducirMenu();

        // Configurar el Alert
        Alert menu = new Alert(Alert.AlertType.CONFIRMATION);
        menu.setTitle("Menu Principal");
        menu.setHeaderText("Bienvenido a Defender Game");

        // Obtener el DialogPane
        DialogPane dialogPane = menu.getDialogPane();

        // Configurar el estilo del DialogPane
        dialogPane.setStyle("-fx-background-color: transparent; -fx-padding: 0;");

        StackPane stackPane = new StackPane(backgroundView);

        Node content = dialogPane.getContent();
        if (content != null) {
            stackPane.getChildren().add(content);
        }

        Node graphic = dialogPane.getGraphic();
        if (graphic != null) {
            stackPane.getChildren().add(graphic);
        }

        dialogPane.setContent(stackPane);

        // Configurar los botones
        ButtonType buttonTypeJugar = new ButtonType("Iniciar Partida");
        ButtonType buttonTypeSalir = new ButtonType("Salir del Juego", ButtonBar.ButtonData.CANCEL_CLOSE);
        menu.getButtonTypes().setAll(buttonTypeJugar, buttonTypeSalir);

        // Obtener el ButtonBar y configurar su estilo
        ButtonBar buttonBar = (ButtonBar) menu.getDialogPane().lookup(".button-bar");
        buttonBar.setStyle("-fx-background-color: transparent;");

        // Centrar los botones verticalmente
        buttonBar.setTranslateY((dialogPane.getHeight() - buttonBar.getHeight()) / 2);

        // Mostrar el menú y manejar la opción seleccionada
        Optional<ButtonType> result = menu.showAndWait();

        result.ifPresent(response -> {
            if (response == buttonTypeJugar) {
                // Lógica para iniciar la partida
                System.out.println("Iniciar Partida");
            } else if (response == buttonTypeSalir) {
                // Lógica para salir del juego
                System.out.println("Salir del Juego");
                Platform.exit();  // Cerrar la aplicación
            }
        });
    }

}
