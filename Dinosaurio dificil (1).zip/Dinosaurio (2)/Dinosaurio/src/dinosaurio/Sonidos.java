package dinosaurio;

import java.io.File;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
//Aqui es donde pongo los sonidos y luego los llamo en la mainpage asi queda mas limpio y se ve bien donde esta cada cosa
public class Sonidos {
    private static MediaPlayer mediaPlayer;

    public static void reproducirFondo() {
        detenerSonido();
        mediaPlayer = crearMediaPlayer("audio/nier.mp3", 0.6, true);
    }

    public static void reproducirGanar() {
        detenerSonido();
        mediaPlayer = crearMediaPlayer("audio/derrota.mp3", 0.8, false);
    }

    public static void reproducirPerder() {
        detenerSonido();
        mediaPlayer = crearMediaPlayer("audio/win.mp3", 0.8, false);
    }

    public static void detenerSonido() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
    }
     public static void reproducirMenu() {
        detenerSonido();
        mediaPlayer = crearMediaPlayer("audio/zombies.mp3", 8, false);
    }

    private static MediaPlayer crearMediaPlayer(String ruta, double volumen, boolean ciclico) {
        Media media = new Media(new File(ruta).toURI().toString());
        MediaPlayer player = new MediaPlayer(media);
        player.setVolume(volumen);
        if (ciclico) {
            player.setCycleCount(MediaPlayer.INDEFINITE);
        }
        player.play();
        return player;
    }
}
